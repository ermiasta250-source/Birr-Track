plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.pocketledger.app"
    compileSdk = 34
    defaultConfig { applicationId = "com.pocketledger.app"; minSdk = 24; targetSdk = 34; versionCode = 2; versionName = "1.1" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}

dependencies { implementation("com.google.android.gms:play-services-code-scanner:16.1.0") }
