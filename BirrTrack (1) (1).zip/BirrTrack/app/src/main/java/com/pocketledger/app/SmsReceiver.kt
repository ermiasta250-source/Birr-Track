package com.pocketledger.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

// Catches every new bank / telebirr SMS (even when the app is closed) and queues it.
// The app imports the queue the next time it is opened (and every few seconds while open).
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val parts = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        if (parts.isEmpty()) return
        val body = parts.joinToString("") { it.messageBody ?: "" }
        if (!Regex("etb|birr", RegexOption.IGNORE_CASE).containsMatchIn(body)) return
        Scheduler.enqueue(c, body, parts[0].timestampMillis, parts[0].originatingAddress ?: "")
    }
}
