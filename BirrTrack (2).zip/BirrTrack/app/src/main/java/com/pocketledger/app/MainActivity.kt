package com.pocketledger.app

import android.Manifest
import android.app.Activity
import android.content.ClipboardManager
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var stopped = false

    private fun js(s: String) = runOnUiThread { web.evaluateJavascript(s, null) }
    private fun sec() = getSharedPreferences("sec", 0)
    private fun hashPin(pin: String, salt: String): String {
        val spec = PBEKeySpec(pin.toCharArray(), Base64.decode(salt, Base64.NO_WRAP), 20000, 256)
        return Base64.encodeToString(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).encoded, Base64.NO_WRAP)
    }
    private fun hasSms() = checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED

    inner class Bridge {
        @JavascriptInterface fun copy(t: String) = runOnUiThread {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("data", t))
        }
        @JavascriptInterface fun clip(): String = try {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.primaryClip?.getItemAt(0)?.coerceToText(this@MainActivity)?.toString() ?: ""
        } catch (e: Exception) { "" }
        @JavascriptInterface fun getHour(): Int = Scheduler.hour(this@MainActivity)
        @JavascriptInterface fun setHour(h: Int) { Scheduler.setHour(this@MainActivity, h) }
        @JavascriptInterface fun testAlert() = runOnUiThread { Scheduler.notifyToday(this@MainActivity) }
        @JavascriptInterface fun saveToday(inn: Double, out: Double, n: Int, day: String) =
            Scheduler.saveToday(this@MainActivity, inn, out, n, day)

        // ---- SMS ----
        @JavascriptInterface fun hasSmsPerm(): Boolean = hasSms()
        @JavascriptInterface fun scan() = runOnUiThread {
            if (hasSms()) deliver() else requestPermissions(arrayOf(Manifest.permission.READ_SMS), 1)
        }

        // ---- password (8 digits) ----
        @JavascriptInterface fun hasPin(): Boolean = sec().contains("h")
        @JavascriptInterface fun setPin(pin: String): Boolean {
            if (!Regex("\\d{8}").matches(pin)) return false
            val salt = Base64.encodeToString(ByteArray(16).also { SecureRandom().nextBytes(it) }, Base64.NO_WRAP)
            sec().edit().putString("s", salt).putString("h", hashPin(pin, salt)).putInt("f", 0).putLong("lu", 0).apply()
            return true
        }
        @JavascriptInterface fun checkPin(pin: String): Int {
            val s = sec(); val now = System.currentTimeMillis()
            if (now < s.getLong("lu", 0)) return -1
            if (hashPin(pin, s.getString("s", "")!!) == s.getString("h", "")) { s.edit().putInt("f", 0).apply(); return 1 }
            val f = s.getInt("f", 0) + 1
            val e = s.edit().putInt("f", f)
            if (f >= 5) e.putLong("lu", now + 30000).putInt("f", 0)
            e.apply(); return 0
        }
        @JavascriptInterface fun resetPin() { sec().edit().clear().apply() }

        // ---- fingerprint / face ----
        @JavascriptInterface fun canBio(): Boolean {
            if (Build.VERSION.SDK_INT < 29) return false
            return try {
                @Suppress("DEPRECATION")
                getSystemService(BiometricManager::class.java).canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS
            } catch (e: Exception) { false }
        }
        @JavascriptInterface fun bio() = runOnUiThread {
            if (Build.VERSION.SDK_INT < 28) return@runOnUiThread
            try {
                val p = BiometricPrompt.Builder(this@MainActivity)
                    .setTitle("Ermi Birr Tracker").setSubtitle("Unlock with fingerprint or face")
                    .setNegativeButton("Use password", mainExecutor, DialogInterface.OnClickListener { _, _ -> js("onBio(false)") })
                    .build()
                p.authenticate(CancellationSignal(), mainExecutor, object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult?) { js("onBio(true)") }
                    override fun onAuthenticationError(c: Int, m: CharSequence?) { js("onBio(false)") }
                })
            } catch (e: Exception) { js("onBio(false)") }
        }
    }

    private fun deliver() {
        val arr = JSONArray()
        val since = System.currentTimeMillis() - 120L * 24 * 3600 * 1000
        val money = Regex("ETB|Birr", RegexOption.IGNORE_CASE)
        for (box in listOf("inbox", "sent")) {
            contentResolver.query(Uri.parse("content://sms/$box"), arrayOf("address", "body", "date"),
                "date > ?", arrayOf(since.toString()), "date DESC")?.use { c ->
                var n = 0
                while (c.moveToNext() && n < 2000) {
                    val body = c.getString(1) ?: continue
                    if (!money.containsMatchIn(body)) continue
                    arr.put(JSONObject().put("addr", c.getString(0) ?: "").put("body", body).put("date", c.getLong(2)))
                    n++
                }
            }
        }
        js("onSms(" + arr.toString() + ")")
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (code == 1) { if (hasSms()) deliver() else js("onSmsDenied()") }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.scheme == "file") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, request.url)) } catch (e: Exception) {}
                return true
            }
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        Scheduler.schedule(this)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
    }

    override fun onStop() { super.onStop(); stopped = true }
    override fun onStart() { super.onStart(); if (stopped) { stopped = false; js("onResumeApp()") } }
}
