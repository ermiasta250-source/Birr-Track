# Birr Track APK (cloud build)
1. Create a free GitHub account, make a new repository, and upload ALL files in this folder (keep the folder structure, including .github).
2. Open the repo's Actions tab -> "Build APK" -> wait ~3-5 minutes for the green check.
3. Open the finished run -> Artifacts -> download BirrTrack-apk -> unzip -> install app-debug.apk on your phone (allow "install unknown apps").
4. In the app tap "Set AI API key" and paste your Anthropic API key (console.anthropic.com).

## SMS reading
On first "Sync SMS" tap, Android asks for SMS permission. The app reads only messages containing ETB/Birr
(CBE, Telebirr, Awash, Dashen, Abyssinia, etc.), parses them on-device, and stores results in localStorage.

## Daily alert
Every day at 21:00 (change it in the app) a notification shows today's total spent and deposited,
calculated on the phone from today's bank/Telebirr SMS. Allow notifications and SMS when asked.
