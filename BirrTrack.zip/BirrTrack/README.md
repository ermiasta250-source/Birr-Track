# Ermi Birr Tracker APK (cloud build)
1. Create a free GitHub account, make a new repository, and upload ALL files in this folder (keep the folder structure, including .github).
2. Open the repo's Actions tab -> "Build APK" -> wait ~3-5 minutes for the green check.
3. Open the finished run -> Artifacts -> download BirrTrack-apk -> unzip -> install app-debug.apk on your phone (allow "install unknown apps").
4. In the app tap "Set AI API key" and paste your Anthropic API key (console.anthropic.com).

## Messages
No SMS permission needed (avoids Play Protect blocking). Copy your bank/Telebirr messages and tap "Paste SMS".
The daily alert shows totals of the transactions saved in the app today.

Developed by Mr Ermias Tadesse — ermitech2023@gmail.com — 0984193465 — Telegram @ermit01
