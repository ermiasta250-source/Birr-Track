package com.pocketledger.app

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView

    inner class Bridge {
        @JavascriptInterface fun hasPerm(): Boolean =
            checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED
        @JavascriptInterface fun scan() = runOnUiThread {
            if (hasPerm()) deliver() else requestPermissions(arrayOf(Manifest.permission.READ_SMS), 1)
        }
        @JavascriptInterface fun getHour(): Int = Scheduler.hour(this@MainActivity)
        @JavascriptInterface fun setHour(h: Int) { Scheduler.setHour(this@MainActivity, h) }
        @JavascriptInterface fun testAlert() = runOnUiThread { Scheduler.notifyToday(this@MainActivity) }
    }

    private fun deliver() {
        val arr = JSONArray()
        val since = System.currentTimeMillis() - 120L * 24 * 3600 * 1000
        for (box in listOf("inbox", "sent")) {
            contentResolver.query(Uri.parse("content://sms/$box"), arrayOf("address", "body", "date"),
                "date > ?", arrayOf(since.toString()), "date DESC")?.use { c ->
                var n = 0
                while (c.moveToNext() && n < 1500) {
                    val body = c.getString(1) ?: continue
                    if (!Regex("ETB|Birr", RegexOption.IGNORE_CASE).containsMatchIn(body)) continue
                    arr.put(JSONObject().put("addr", c.getString(0) ?: "").put("body", body).put("date", c.getLong(2)))
                    n++
                }
            }
        }
        web.evaluateJavascript("window.onSms(" + arr.toString() + ")", null)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (hasSms()) deliver()
    }
    private fun hasSms() = checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        Scheduler.schedule(this)
        val need = mutableListOf<String>()
        if (!hasSms()) need.add(Manifest.permission.READ_SMS)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 2)
    }
}
