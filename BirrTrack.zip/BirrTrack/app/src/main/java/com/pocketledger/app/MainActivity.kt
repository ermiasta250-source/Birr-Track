package com.pocketledger.app

import android.Manifest
import android.app.Activity
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var web: WebView

    inner class Bridge {
        @JavascriptInterface fun copy(t: String) = runOnUiThread {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("data", t))
        }
        @JavascriptInterface fun clip(): String = try {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.primaryClip?.getItemAt(0)?.coerceToText(this@MainActivity)?.toString() ?: ""
        } catch (e: Exception) { "" }
        @JavascriptInterface fun getHour(): Int = Scheduler.hour(this@MainActivity)
        @JavascriptInterface fun setHour(h: Int) { Scheduler.setHour(this@MainActivity, h) }
        @JavascriptInterface fun testAlert() = runOnUiThread { Scheduler.notifyToday(this@MainActivity) }
        @JavascriptInterface fun saveToday(inn: Double, out: Double, n: Int, day: String) =
            Scheduler.saveToday(this@MainActivity, inn, out, n, day)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.scheme == "file") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, request.url)) } catch (e: Exception) {}
                return true
            }
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        Scheduler.schedule(this)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { super.onBackPressed() }
}
