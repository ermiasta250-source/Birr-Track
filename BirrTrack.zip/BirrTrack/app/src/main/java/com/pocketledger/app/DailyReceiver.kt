package com.pocketledger.app

import android.app.*
import android.content.*
import android.os.Build
import java.text.SimpleDateFormat
import java.util.*

object Scheduler {
    fun hour(c: Context) = c.getSharedPreferences("bt", 0).getInt("hour", 21)
    fun setHour(c: Context, h: Int) { c.getSharedPreferences("bt", 0).edit().putInt("hour", h).apply(); schedule(c) }
    fun saveToday(c: Context, inn: Double, out: Double, n: Int, day: String) {
        c.getSharedPreferences("bt", 0).edit().putString("in", inn.toString()).putString("out", out.toString())
            .putInt("n", n).putString("day", day).apply()
    }
    fun schedule(c: Context) {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour(c)); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
            if (timeInMillis <= System.currentTimeMillis() + 60000) add(Calendar.DAY_OF_YEAR, 1)
        }
        val pi = PendingIntent.getBroadcast(c, 7, Intent(c, DailyReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager)
            .setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
    }
    private fun fmt(v: Double) = "ETB " + String.format("%,.2f", v)

    fun notifyToday(c: Context) {
        val sp = c.getSharedPreferences("bt", 0)
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val has = sp.getString("day", "") == today && sp.getInt("n", 0) > 0
        val inn = if (has) sp.getString("in", "0")!!.toDouble() else 0.0
        val out = if (has) sp.getString("out", "0")!!.toDouble() else 0.0
        val n = if (has) sp.getInt("n", 0) else 0
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("daily", "Daily summary", NotificationManager.IMPORTANCE_DEFAULT))
        val open = PendingIntent.getActivity(c, 8, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        @Suppress("DEPRECATION")
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, "daily") else Notification.Builder(c)
        val text = if (!has) "No transactions saved today. Paste today's bank/Telebirr messages in the app." else "Spent ${fmt(out)}  \u2022  Deposited ${fmt(inn)}"
        b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Ermi Birr Tracker • today ($n)")
            .setContentText(text).setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(open).setAutoCancel(true)
        nm.notify(1, b.build())
    }
}

class DailyReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Scheduler.schedule(c)
        if (i.action != Intent.ACTION_BOOT_COMPLETED) Scheduler.notifyToday(c)
    }
}
