package com.pocketledger.app

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import java.util.Calendar

object Scheduler {
    fun hour(c: Context) = c.getSharedPreferences("bt", 0).getInt("hour", 21)
    fun setHour(c: Context, h: Int) { c.getSharedPreferences("bt", 0).edit().putInt("hour", h).apply(); schedule(c) }
    fun schedule(c: Context) {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour(c)); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
            if (timeInMillis <= System.currentTimeMillis() + 60000) add(Calendar.DAY_OF_YEAR, 1)
        }
        val pi = PendingIntent.getBroadcast(c, 7, Intent(c, DailyReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager)
            .setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
    }

    private fun fmt(v: Double) = "ETB " + String.format("%,.2f", v)

    fun notifyToday(c: Context) {
        if (c.checkSelfPermission(Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) return
        val start = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        var inn = 0.0; var out = 0.0; var n = 0
        val money = Regex("ETB|Birr", RegexOption.IGNORE_CASE)
        val skip = Regex("\\botp\\b|verification code|password", RegexOption.IGNORE_CASE)
        val balRx = Regex("(?:current |available |total )?balance[^\\d]{0,30}[\\d,]+(?:\\.\\d+)?", RegexOption.IGNORE_CASE)
        val amtRx = Regex("(?:ETB|Birr|Br\\.?)\\s*([\\d,]+(?:\\.\\d+)?)|([\\d,]+(?:\\.\\d+)?)\\s*(?:ETB|Birr)", RegexOption.IGNORE_CASE)
        val crRx = Regex("credited|received|deposit|cash in|refund", RegexOption.IGNORE_CASE)
        val dbRx = Regex("debited|transferred|paid|payment|sent|withdraw|purchase|bought|recharg|airtime", RegexOption.IGNORE_CASE)
        for (box in listOf("inbox", "sent")) {
            c.contentResolver.query(Uri.parse("content://sms/$box"), arrayOf("body"), "date >= ?", arrayOf(start.toString()), null)?.use { cur ->
                while (cur.moveToNext()) {
                    val b = cur.getString(0) ?: continue
                    if (!money.containsMatchIn(b) || skip.containsMatchIn(b)) continue
                    val main = b.replace(balRx, "")
                    val m = amtRx.find(main) ?: continue
                    val amt = (m.groupValues[1].ifEmpty { m.groupValues[2] }).replace(",", "").toDoubleOrNull() ?: continue
                    val ci = crRx.find(main)?.range?.first ?: -1
                    val di = dbRx.find(main)?.range?.first ?: -1
                    if (ci < 0 && di < 0) continue
                    if (ci >= 0 && (di < 0 || ci < di)) inn += amt else out += amt
                    n++
                }
            }
        }
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("daily", "Daily summary", NotificationManager.IMPORTANCE_DEFAULT))
        val open = PendingIntent.getActivity(c, 8, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        @Suppress("DEPRECATION")
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, "daily") else Notification.Builder(c)
        val text = if (n == 0) "No bank or Telebirr transactions today." else "Spent ${fmt(out)}  •  Deposited ${fmt(inn)}"
        b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Today's money ($n transactions)")
            .setContentText(text).setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(open).setAutoCancel(true)
        nm.notify(1, b.build())
    }
}

class DailyReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Scheduler.schedule(c)
        if (i.action != Intent.ACTION_BOOT_COMPLETED) Scheduler.notifyToday(c)
    }
}
