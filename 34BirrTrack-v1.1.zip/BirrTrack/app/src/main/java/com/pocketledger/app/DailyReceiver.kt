package com.pocketledger.app

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import java.text.SimpleDateFormat
import java.util.*

object Scheduler {
    fun hour(c: Context) = c.getSharedPreferences("bt", 0).getInt("hour", 21)
    fun setHour(c: Context, h: Int) { c.getSharedPreferences("bt", 0).edit().putInt("hour", h).apply(); schedule(c) }
    fun saveToday(c: Context, inn: Double, out: Double, n: Int, day: String) {
        c.getSharedPreferences("bt", 0).edit().putString("in", inn.toString()).putString("out", out.toString())
            .putInt("n", n).putString("day", day).apply()
    }
    fun schedule(c: Context) {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour(c)); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
            if (timeInMillis <= System.currentTimeMillis() + 60000) add(Calendar.DAY_OF_YEAR, 1)
        }
        val pi = PendingIntent.getBroadcast(c, 7, Intent(c, DailyReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager)
            .setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
    }
    private fun fmt(v: Double) = "ETB " + String.format("%,.2f", v)

    // totals of today's bank/telebirr SMS (needs SMS permission)
    private fun fromSms(c: Context): Triple<Double, Double, Int>? {
        if (c.checkSelfPermission(Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) return null
        val start = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        var inn = 0.0; var out = 0.0; var n = 0
        val money = Regex("ETB|Birr", RegexOption.IGNORE_CASE)
        val skip = Regex("\\botp\\b|verification code|password|expire|promo|offer|bonus|reminder", RegexOption.IGNORE_CASE)
        val balRx = Regex("(?:current |available |total )?balance[^\\d]{0,30}[\\d,]+(?:\\.\\d+)?", RegexOption.IGNORE_CASE)
        val amtRx = Regex("(?:ETB|Birr|Br\\.?)\\s*([\\d,]+(?:\\.\\d+)?)|([\\d,]+(?:\\.\\d+)?)\\s*(?:ETB|Birr)", RegexOption.IGNORE_CASE)
        val crRx = Regex("credited|received|deposit|cash in|refund", RegexOption.IGNORE_CASE)
        val dbRx = Regex("debited|transferred|paid|payment|sent|withdraw|purchase|bought|recharg", RegexOption.IGNORE_CASE)
        c.contentResolver.query(Uri.parse("content://sms/inbox"), arrayOf("body"), "date >= ?", arrayOf(start.toString()), null)?.use { cur ->
            while (cur.moveToNext()) {
                val b = cur.getString(0) ?: continue
                if (!money.containsMatchIn(b) || skip.containsMatchIn(b)) continue
                val main = b.replace(balRx, "")
                val m = amtRx.find(main) ?: continue
                val amt = (m.groupValues[1].ifEmpty { m.groupValues[2] }).replace(",", "").toDoubleOrNull() ?: continue
                val ci = crRx.find(main)?.range?.first ?: -1
                val di = dbRx.find(main)?.range?.first ?: -1
                if (ci < 0 && di < 0) continue
                if (ci >= 0 && (di < 0 || ci < di)) inn += amt else out += amt
                n++
            }
        }
        return Triple(inn, out, n)
    }

    fun notifyToday(c: Context) {
        val sp = c.getSharedPreferences("bt", 0)
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        var inn = 0.0; var out = 0.0; var n = 0
        val s = fromSms(c)
        if (s != null) { inn = s.first; out = s.second; n = s.third }
        else if (sp.getString("day", "") == today) {
            inn = sp.getString("in", "0")!!.toDouble(); out = sp.getString("out", "0")!!.toDouble(); n = sp.getInt("n", 0)
        }
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("daily", "Daily summary", NotificationManager.IMPORTANCE_DEFAULT))
        val open = PendingIntent.getActivity(c, 8, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        @Suppress("DEPRECATION")
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, "daily") else Notification.Builder(c)
        val text = if (n == 0) "No deposits or expenses recorded today." else "Spent ${fmt(out)}  \u2022  Deposited ${fmt(inn)}"
        b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Ermi Birr Tracker \u2022 today ($n)")
            .setContentText(text).setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(open).setAutoCancel(true)
        nm.notify(1, b.build())
    }
}

class DailyReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Scheduler.schedule(c)
        if (i.action != Intent.ACTION_BOOT_COMPLETED) Scheduler.notifyToday(c)
    }
}
