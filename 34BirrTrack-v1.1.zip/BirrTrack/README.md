# Ermi Birr Tracker APK (cloud build)
1. Create a free GitHub account, make a new repository, and upload ALL files in this folder (keep the folder structure, including .github).
2. Open the repo's Actions tab -> "Build APK" -> wait ~3-5 minutes for the green check.
3. Open the finished run -> Artifacts -> download BirrTrack-apk -> unzip -> install app-debug.apk on your phone (allow "install unknown apps").
4. In the app tap "Set AI API key" and paste your Anthropic API key (console.anthropic.com).

## New in v1.1
- **Scan tab** – scan the QR code on a CBE, Telebirr, Dashen, Awash, Abyssinia, CBE Birr, M-PESA… receipt with the camera, or read it from a screenshot/photo. The bank and reference are filled in automatically. The QR's website is checked and flagged if it is not a known bank domain.
  - *Check my SMS* compares the receipt with the bank messages on the phone (works offline).
  - *Verify on verify.et* copies the reference and opens https://verify.et/verify/<bank>. If you paste a verify.et API key in More > Settings, the check runs inside the app instead.
- **FX tab** – daily Birr rates (USD, EUR, GBP, SAR, AED, CNY, KES, CAD) with a chart, 7/30/90-day range, high/low/average and a day-by-day table. It updates itself whenever the phone gets internet (app open, back online, every 3 hours) and fills in any days that were missed.
- The camera permission is only asked when you tap Scan QR code.

## Messages
No SMS permission needed (avoids Play Protect blocking). Copy your bank/Telebirr messages and tap "Paste SMS".
The daily alert shows totals of the transactions saved in the app today.

Developed by Mr Ermias Tadesse — ermitech2023@gmail.com — 0984193465 — Telegram @ermit01
