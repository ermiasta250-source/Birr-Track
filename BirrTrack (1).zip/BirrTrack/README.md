# Ermi Birr Tracker APK (cloud build)
1. Create a free GitHub account, make a new repository, and upload ALL files in this folder (keep the folder structure, including .github).
2. Open the repo's Actions tab -> "Build APK" -> wait ~3-5 minutes for the green check.
3. Open the finished run -> Artifacts -> download BirrTrack-apk -> unzip -> install app-debug.apk on your phone (allow "install unknown apps").
4. In the app tap "Set AI API key" and paste your Anthropic API key (console.anthropic.com).

## Messages (SMS)
The app now reads your bank/Telebirr SMS directly. On first open (after you create your PIN) allow the SMS permission.
New messages are caught even when the app is closed and added when you open it. The paste option still works as a backup.
Note: Play Protect may warn about an app with SMS access when you install the APK. Tap "Install anyway" (this is your own build).

## Security
8-digit PIN on first launch, plus fingerprint/face if your phone supports it. The app locks again after 30 seconds away.
Screenshots are blocked. Forgot PIN = reset, which erases the app data.

## Online mode
When the phone goes online the app imports new messages, refreshes exchange rates, and (with an API key) searches the internet for the latest bank rate and inflation. Offline it answers from your saved data.

## Verify receipt
Paste a customer's receipt link or ID. The app asks the bank's own receipt page (Telebirr, CBE, Dashen) whether it exists, is completed, matches the amount and went to your business name (set it in More > Settings). It also checks scam wording, link domain and your own SMS.

Developed by Mr Ermias Tadesse — ermitech2023@gmail.com — 0984193465 — Telegram @ermit01
