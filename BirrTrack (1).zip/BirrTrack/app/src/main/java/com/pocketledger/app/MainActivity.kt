package com.pocketledger.app

import android.Manifest
import android.app.Activity
import android.content.ClipboardManager
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var away = 0L

    private fun js(s: String) = runOnUiThread {
        if (::web.isInitialized) web.evaluateJavascript("try{$s}catch(e){}", null)
    }
    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
    private fun unhex(s: String) = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    private fun hashPin(pin: String, salt: ByteArray): String {
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1")
        return hex(f.generateSecret(PBEKeySpec(pin.toCharArray(), salt, 60000, 160)).encoded)
    }

    inner class Bridge {
        // ---- clipboard / daily alert ----
        @JavascriptInterface fun copy(t: String) = runOnUiThread {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("data", t))
        }
        @JavascriptInterface fun clip(): String = try {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.primaryClip?.getItemAt(0)?.coerceToText(this@MainActivity)?.toString() ?: ""
        } catch (e: Exception) { "" }
        @JavascriptInterface fun getHour(): Int = Scheduler.hour(this@MainActivity)
        @JavascriptInterface fun setHour(h: Int) { Scheduler.setHour(this@MainActivity, h) }
        @JavascriptInterface fun testAlert() = runOnUiThread { Scheduler.notifyToday(this@MainActivity) }
        @JavascriptInterface fun saveToday(inn: Double, out: Double, n: Int, day: String) =
            Scheduler.saveToday(this@MainActivity, inn, out, n, day)

        // ---- SMS ----
        @JavascriptInterface fun hasSms(): Boolean =
            checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED
        @JavascriptInterface fun requestSms() = runOnUiThread {
            requestPermissions(arrayOf(Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS), 3)
        }
        @JavascriptInterface fun drainPending(): String = Scheduler.drain(this@MainActivity)
        @JavascriptInterface fun readSms(since: Long): String {
            val out = JSONArray()
            if (!hasSms()) return out.toString()
            try {
                val rx = Regex("etb|birr", RegexOption.IGNORE_CASE)
                contentResolver.query(Uri.parse("content://sms/inbox"), arrayOf("body", "date", "address"),
                    "date > ?", arrayOf(since.toString()), "date DESC")?.use { c ->
                    var n = 0
                    while (c.moveToNext() && n < 600) {
                        val b = c.getString(0)
                        if (b == null || !rx.containsMatchIn(b)) continue
                        out.put(JSONObject().put("b", b).put("d", c.getLong(1)).put("a", c.getString(2) ?: ""))
                        n++
                    }
                }
            } catch (e: Exception) { }
            return out.toString()
        }

        // ---- ask the bank's own receipt page (official hosts only) ----
        @JavascriptInterface fun fetchReceipt(id: Int, url: String) {
            Thread {
                var code = 0
                var type = ""
                var body = ""
                try {
                    val u = Uri.parse(url)
                    val okHost = listOf("transactioninfo.ethiotelecom.et", "mbreciept.cbe.com.et", "receipt.dashensuperapp.com")
                        .contains(u.host ?: "")
                    if (u.scheme == "https" && okHost) {
                        val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                        c.connectTimeout = 10000
                        c.readTimeout = 10000
                        c.setRequestProperty("User-Agent", "Mozilla/5.0")
                        code = c.responseCode
                        type = c.contentType ?: ""
                        val st = if (code >= 400) c.errorStream else c.inputStream
                        if (st != null && !type.contains("pdf", true)) {
                            val bytes = st.use { it.readBytes() }
                            body = String(bytes.copyOf(minOf(bytes.size, 300000)), Charsets.UTF_8)
                        }
                        c.disconnect()
                    }
                } catch (e: Exception) { code = -1 }
                val j = JSONObject().put("code", code).put("type", type).put("body", body)
                js("onReceipt($id, ${JSONObject.quote(j.toString())})")
            }.start()
        }

        // ---- PIN (8 digits, salted PBKDF2, lock-out after 5 wrong tries) ----
        @JavascriptInterface fun hasPin(): Boolean =
            getSharedPreferences("sec", 0).getString("hash", null) != null
        @JavascriptInterface fun setPin(pin: String): Boolean {
            if (!Regex("\\d{8}").matches(pin)) return false
            val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
            getSharedPreferences("sec", 0).edit().putString("salt", hex(salt)).putString("hash", hashPin(pin, salt))
                .putInt("fails", 0).putLong("until", 0).apply()
            return true
        }
        // 0 = correct, -1 = wrong, >0 = seconds to wait
        @JavascriptInterface fun checkPin(pin: String): Int {
            val sp = getSharedPreferences("sec", 0)
            val now = System.currentTimeMillis()
            val until = sp.getLong("until", 0)
            if (until > now) return ((until - now) / 1000 + 1).toInt()
            val salt = sp.getString("salt", null) ?: return -1
            val good = sp.getString("hash", "") ?: ""
            if (MessageDigest.isEqual(hashPin(pin, unhex(salt)).toByteArray(), good.toByteArray())) {
                sp.edit().putInt("fails", 0).putLong("until", 0).apply()
                return 0
            }
            val f = sp.getInt("fails", 0) + 1
            val e = sp.edit().putInt("fails", f)
            if (f >= 5) {
                val secs = minOf(30L shl minOf(f - 5, 7), 3600L)
                e.putLong("until", now + secs * 1000)
            }
            e.apply()
            return -1
        }
        @JavascriptInterface fun resetPin() {
            getSharedPreferences("sec", 0).edit().clear().apply()
            Scheduler.clearAll(this@MainActivity)
        }

        // ---- fingerprint / face ----
        @JavascriptInterface fun canBio(): Boolean {
            if (Build.VERSION.SDK_INT < 28) return false
            return try {
                if (Build.VERSION.SDK_INT >= 30) {
                    getSystemService(BiometricManager::class.java)
                        .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS
                } else if (Build.VERSION.SDK_INT == 29) {
                    @Suppress("DEPRECATION")
                    getSystemService(BiometricManager::class.java).canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS
                } else packageManager.hasSystemFeature(PackageManager.FEATURE_FINGERPRINT)
            } catch (e: Exception) { false }
        }
        @JavascriptInterface fun bio() = runOnUiThread {
            if (Build.VERSION.SDK_INT >= 28) {
                val cb = object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult?) { js("onBio(true)") }
                    override fun onAuthenticationError(code: Int, msg: CharSequence?) { js("onBio(false)") }
                }
                try {
                    BiometricPrompt.Builder(this@MainActivity).setTitle("Unlock Birr Tracker")
                        .setNegativeButton("Use PIN", mainExecutor, DialogInterface.OnClickListener { _, _ -> js("onBio(false)") })
                        .build().authenticate(CancellationSignal(), mainExecutor, cb)
                } catch (e: Exception) { js("onBio(false)") }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // hides the app from screenshots and the recent-apps preview
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.scheme == "file") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, request.url)) } catch (e: Exception) {}
                return true
            }
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        Scheduler.schedule(this)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (code == 3) js("onSmsPerm()")
    }

    override fun onStop() { super.onStop(); away = System.currentTimeMillis() }
    override fun onStart() {
        super.onStart()
        // lock again when you come back after more than 30 seconds
        if (away > 0 && System.currentTimeMillis() - away > 30000) js("lockNow()")
        away = 0
    }
    override fun onResume() { super.onResume(); js("onResumeApp()") }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { super.onBackPressed() }
}
