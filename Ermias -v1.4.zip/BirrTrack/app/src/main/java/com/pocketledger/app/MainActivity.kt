package com.pocketledger.app

import android.Manifest
import android.app.Activity
import android.content.ClipboardManager
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.integration.android.IntentIntegrator
import java.net.HttpURLConnection
import java.net.URL
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var stopped = false
    private var external = false   // camera / photo picker open: do not re-lock when we come back

    private fun js(s: String) = runOnUiThread { web.evaluateJavascript(s, null) }
    private fun sec() = getSharedPreferences("sec", 0)
    private fun hashPin(pin: String, salt: String): String {
        val spec = PBEKeySpec(pin.toCharArray(), Base64.decode(salt, Base64.NO_WRAP), 20000, 256)
        return Base64.encodeToString(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).encoded, Base64.NO_WRAP)
    }
    private fun hasSms() = checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED

    inner class Bridge {
        @JavascriptInterface fun copy(t: String) = runOnUiThread {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("data", t))
        }
        @JavascriptInterface fun clip(): String = try {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.primaryClip?.getItemAt(0)?.coerceToText(this@MainActivity)?.toString() ?: ""
        } catch (e: Exception) { "" }
        @JavascriptInterface fun getHour(): Int = Scheduler.hour(this@MainActivity)
        @JavascriptInterface fun setHour(h: Int) { Scheduler.setHour(this@MainActivity, h) }
        @JavascriptInterface fun testAlert() = runOnUiThread { Scheduler.notifyToday(this@MainActivity) }
        @JavascriptInterface fun saveToday(inn: Double, out: Double, n: Int, day: String) =
            Scheduler.saveToday(this@MainActivity, inn, out, n, day)


        // ---- QR scanner (camera) and QR from a photo/screenshot ----
        @JavascriptInterface fun scanQr() = runOnUiThread {
            external = true
            try {
                IntentIntegrator(this@MainActivity)
                    .setDesiredBarcodeFormats(IntentIntegrator.QR_CODE)
                    .setPrompt("Point the camera at the receipt QR code")
                    .setBeepEnabled(false).setOrientationLocked(false).initiateScan()
            } catch (e: Exception) { external = false; js("onQrFail('error')") }
        }
        @JavascriptInterface fun pickImage() = runOnUiThread {
            external = true
            try {
                startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE), 3)
            } catch (e: Exception) { external = false; js("onQrFail('error')") }
        }
        @JavascriptInterface fun openAppSettings() = runOnUiThread {
            external = true
            try {
                startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + packageName)))
            } catch (e: Exception) { external = false }
        }
        @JavascriptInterface fun openUrl(u: String) = runOnUiThread {
            try {
                val uri = Uri.parse(u)
                if (uri.scheme == "https") startActivity(Intent(Intent.ACTION_VIEW, uri))
            } catch (e: Exception) {}
        }

        // ---- verify.et API (needs the user's own API key) ----
        @JavascriptInterface fun verifyApi(key: String, body: String) {
            Thread {
                val out = JSONObject()
                try {
                    var r = http("POST", "https://verify.et/api/verify?waitMs=5000", key, body)
                    if (r.first == 202) {
                        val su = JSONObject(r.second).optString("statusUrl")
                        if (su.startsWith("/")) {
                            var i = 0
                            while (i < 6) {
                                Thread.sleep(1500)
                                val g = http("GET", "https://verify.et$su", key, null)
                                r = g
                                val ps = JSONObject(g.second).optJSONObject("data")?.optString("processingStatus") ?: ""
                                if (g.first != 200 || ps == "completed" || ps == "failed") break
                                i++
                            }
                        }
                    }
                    out.put("http", r.first).put("body", r.second)
                } catch (e: Exception) {
                    out.put("http", 0).put("body", e.message ?: "error")
                }
                js("onVerifyApi(" + out.toString() + ")")
            }.start()
        }

        // ---- SMS ----
        @JavascriptInterface fun hasSmsPerm(): Boolean = hasSms()
        @JavascriptInterface fun scan() = runOnUiThread {
            if (hasSms()) deliver() else requestPermissions(arrayOf(Manifest.permission.READ_SMS), 1)
        }

        // ---- password (8 digits) ----
        @JavascriptInterface fun hasPin(): Boolean = sec().contains("h")
        @JavascriptInterface fun setPin(pin: String): Boolean {
            if (!Regex("\\d{8}").matches(pin)) return false
            val salt = Base64.encodeToString(ByteArray(16).also { SecureRandom().nextBytes(it) }, Base64.NO_WRAP)
            sec().edit().putString("s", salt).putString("h", hashPin(pin, salt)).putInt("f", 0).putLong("lu", 0).apply()
            return true
        }
        @JavascriptInterface fun checkPin(pin: String): Int {
            val s = sec(); val now = System.currentTimeMillis()
            if (now < s.getLong("lu", 0)) return -1
            if (hashPin(pin, s.getString("s", "")!!) == s.getString("h", "")) { s.edit().putInt("f", 0).apply(); return 1 }
            val f = s.getInt("f", 0) + 1
            val e = s.edit().putInt("f", f)
            if (f >= 5) e.putLong("lu", now + 30000).putInt("f", 0)
            e.apply(); return 0
        }
        @JavascriptInterface fun resetPin() { sec().edit().clear().apply() }

        // ---- fingerprint / face ----
        @JavascriptInterface fun canBio(): Boolean {
            if (Build.VERSION.SDK_INT < 29) return false
            return try {
                @Suppress("DEPRECATION")
                getSystemService(BiometricManager::class.java).canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS
            } catch (e: Exception) { false }
        }
        @JavascriptInterface fun bio() = runOnUiThread {
            if (Build.VERSION.SDK_INT < 28) return@runOnUiThread
            try {
                val p = BiometricPrompt.Builder(this@MainActivity)
                    .setTitle("Ermi Birr Tracker").setSubtitle("Unlock with fingerprint or face")
                    .setNegativeButton("Use password", mainExecutor, DialogInterface.OnClickListener { _, _ -> js("onBio(false)") })
                    .build()
                p.authenticate(CancellationSignal(), mainExecutor, object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult?) { js("onBio(true)") }
                    override fun onAuthenticationError(c: Int, m: CharSequence?) { js("onBio(false)") }
                })
            } catch (e: Exception) { js("onBio(false)") }
        }
    }


    private fun http(method: String, url: String, key: String, body: String?): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method; c.connectTimeout = 10000; c.readTimeout = 15000
            c.setRequestProperty("x-api-key", key); c.setRequestProperty("Accept", "application/json")
            if (body != null) {
                c.doOutput = true; c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toByteArray()) }
            }
            val code = c.responseCode
            val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            return Pair(code, txt)
        } finally { c.disconnect() }
    }

    // read a QR code out of a picked photo / screenshot
    private fun decodeQr(uri: Uri) {
        Thread {
            var text: String? = null
            try {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                var sample = 1
                while (o.outWidth / sample > 3000 || o.outHeight / sample > 3000) sample *= 2
                val bm: Bitmap? = contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
                }
                if (bm != null) {
                    val w = bm.width; val h = bm.height
                    val px = IntArray(w * h); bm.getPixels(px, 0, w, 0, 0, w, h); bm.recycle()
                    val hints = mapOf(DecodeHintType.TRY_HARDER to true, DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE))
                    val src = RGBLuminanceSource(w, h, px)
                    for (s in listOf(src, src.invert())) {
                        try { text = MultiFormatReader().decode(BinaryBitmap(HybridBinarizer(s)), hints).text; break }
                        catch (e: Exception) { }
                    }
                }
            } catch (e: Exception) { }
            val t = text
            if (t != null) js("onQr(" + JSONObject.quote(t) + ")") else js("onQrFail('none')")
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == IntentIntegrator.REQUEST_CODE) {
            val t = IntentIntegrator.parseActivityResult(req, res, data)?.contents
            if (t != null) js("onQr(" + JSONObject.quote(t) + ")") else js("onQrFail('cancel')")
        } else if (req == 3) {
            val u = data?.data
            if (res == RESULT_OK && u != null) decodeQr(u) else js("onQrFail('cancel')")
        }
    }

    private fun deliver() {
        val arr = JSONArray()
        val since = System.currentTimeMillis() - 120L * 24 * 3600 * 1000
        val money = Regex("ETB|Birr", RegexOption.IGNORE_CASE)
        for (box in listOf("inbox", "sent")) {
            contentResolver.query(Uri.parse("content://sms/$box"), arrayOf("address", "body", "date"),
                "date > ?", arrayOf(since.toString()), "date DESC")?.use { c ->
                var n = 0
                while (c.moveToNext() && n < 2000) {
                    val body = c.getString(1) ?: continue
                    if (!money.containsMatchIn(body)) continue
                    arr.put(JSONObject().put("addr", c.getString(0) ?: "").put("body", body).put("date", c.getLong(2)))
                    n++
                }
            }
        }
        js("onSms(" + arr.toString() + ")")
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (code == 1) { if (hasSms()) deliver() else js("onSmsDenied()") }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.scheme == "file") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, request.url)) } catch (e: Exception) {}
                return true
            }
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        Scheduler.schedule(this)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
    }

    override fun onStop() { super.onStop(); stopped = true }
    override fun onStart() { super.onStart(); if (stopped) { stopped = false; if (external) external = false else js("onResumeApp()") } }
}
